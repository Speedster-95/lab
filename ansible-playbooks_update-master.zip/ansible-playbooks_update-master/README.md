# ansible-playbooks

This repository is an Ansible script used to deploy the TAP platform.

Additional documentation:
* [Ansible roles in this repository](./ROLES.md)
